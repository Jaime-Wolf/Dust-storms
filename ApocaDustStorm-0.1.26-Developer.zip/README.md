# ApocaDustStorm 0.1.26

Thick worldwide dust storms inspired by Mad Max (2015), with a gradual approach and clearing, changing directional wind, low visibility and overcast lighting. Includes blowing ground dust, colliding twigs and sticks, gentle vehicle buffeting, sand-on-metal audio, branching dust lightning and occasional edible windblown lizards.

## Storm hazards

- Strong wind slows the player and AI. AI never receive storm health damage.
- Exposed players take damage immediately. Caves, buildings and conex containers provide shelter and stop damage.
- A vehicle initially provides 90% protection, falling gradually to 25% after five minutes in hazardous dust. Proper shelter restores protection gradually; exiting and re-entering a vehicle does not reset it.
- Dusty screen edges and a small icon above the compass show exposure, vehicle cover or shelter. Active storms interrupt exposed sleep, including in vehicles, without a sleep or wake health penalty. Sleeping in proper shelter works normally.
- Gusts apply modest horizontal pressure to the driven vehicle. The storm does not lift vehicles, suck off parts or directly damage vehicle parts. Dust lightning adds light and sound without strike damage.

## Installation and updating

Requires BepInEx 5 x64 and Apocasetter. Built against the installed Apocasetter 2.0.9; the dependency is not bundled.

1. Close Apocalypter.
2. Extract this ZIP into the Apocalypter game folder, merging the existing BepInEx folder. The DLL belongs at BepInEx/plugins/ApocaDustStorm/ApocaDustStorm.dll.
3. Start the game and adjust the mod through Apocasetter's MODS menu.

Existing settings are retained in BepInEx/config/local.apocalypter.duststorm.cfg. Replace the previous storm DLL when updating; keep only one copy. The gearbox and chase-camera mods remain separate.

## Settings and timing

Automatic storms can arrive in daytime or at night. Defaults are a random 5-15 minutes of normal play, with a 90-second build-up and 75-second clearing, adjusted for shorter storms. After five minutes of calm weather, each eligible minute has a 6% chance of starting a storm. An arrival is not guaranteed immediately after loading.

Storms use a random north, south, east or west wind with directional variation. Storm appearance, chance, duration, wind, debris, audio, lightning, headlights, vehicle buffeting, movement resistance, player damage and indicators are adjustable. All thirteen Effects sliders default to 1.00; your saved choices are preserved. Set Player exposure damage to 0 for no health damage; exposed sleep is still interrupted.

The mod's automatic storms operate independently of the vanilla Dust Storm Off switch by default, so vanilla storms may remain off. Enable Follow vanilla storm switch if you want that option to also disable this mod's automatic storms.

## Release and development builds

This release has no storm or lightning testing hotkeys. Normal automatic weather remains available.

ApocaDustStorm-0.1.26-Dev.zip is a separate installable development variant with the testing controls. Install either the release or dev variant, replacing the same DLL; never install both together. Both use the same plugin identity and settings file. Old preview-key values may remain in the config but cannot trigger the release.

ApocaDustStorm-0.1.26-Developer.zip contains source and verification material only. It is not an installation package. Both installable ZIPs contain only the DLL and README files.

## Compatibility and credits

Works with the separate ApocaChaseCamera 0.1.5. The optional NPCAI movement adapter was checked against the installed NPCAI 1.2.0; AI health remains untouched. Unusual versions or other weather/rendering mods may need a compatibility test.

Storm atmosphere inspired by Mad Max (2015). Thanks to Sawyer, creator of Apocalypter. Native wind and food assets are loaded from the installed game and are not redistributed. This mod adds no telemetry or network requests.

## Changes in 0.1.26

The release compiles out the storm/lightning testing key handlers and their settings. The dev build retains F8 and N. Show test status becomes Show storm notices, preserving the previous preference. Gameplay and effect tuning from the user-tested 0.1.25 build are retained, including first-person fog and post-storm lighting recovery.
