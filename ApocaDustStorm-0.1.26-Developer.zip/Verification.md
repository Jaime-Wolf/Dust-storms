# ApocaDustStorm 0.1.26 verification

Prepared October 8, 2026. The user confirmed that the preceding 0.1.25 build checks out in game, including the latest rendering/lighting corrections. Version 0.1.26 changes release/development controls and packaging, not weather, audio, physics, hazards or effect tuning. These newly compiled variants have not separately been played in game.

## Compiled variants

Release is built without APOCA_DEV; development is built with it. Release contains no PreviewKey/DischargeKey fields, preview config bindings, test HUD label or Input.GetKeyDown calls. Dev retains both preview fields, bindings and handlers: F8 storm start/clear and N lightning preview. Their plugin names identify release/dev, but both share local.apocalypter.duststorm and version 0.1.26. Install only one.

The old Show test status preference migrates to Show storm notices and is removed from active settings. Saved preview keys may remain orphaned in the config and are reused by dev; the release has no handlers to read them. The legacy F9-to-N migration runs only in dev.

Verification/check-variants.ps1 inspected both actual DLLs. It also compared 286 shared gameplay method bodies, normalizing only the compiler's random private literal-array owner IDs; embedded literal-array bytes matched separately. Plugin/StormRunner methods are excluded from that equivalence comparison because their intended input/UI paths differ.

## Regression checks

- 234 model, scheduling, wind and dust-flow assertions passed.
- 364 simulated runtime assertions passed.
- 25 real-Harmony integration assertions passed against the installed loader library and controlled native/NPCAI-shaped fixtures.
- Total regression assertions: 623. Compiled-variant checks are separate.
- Both DLLs passed native target inspection: all eleven Harmony targets and two optional NPCAI targets; player-only health writes, capped driver-wind force, no explosion-force, networking or file-write calls.
- Both retained the native ImageEffectOpaque stage, original color source and explicit fog pass 0. Neither contains an ambient-probe setter. Both retain one guarded GI recovery call and next-frame camera-scope cleanup.

The Harmony fixture compiler reports an unused default-false camera-stub field; compilation and execution succeeded. Tests validate model/state/contracts and installed patch signatures, not Unity GPU output or PhysX simulation.

## Packaging and saved state

Release: Releases/ApocaDustStorm-0.1.26.zip. Installable dev: Releases/ApocaDustStorm-0.1.26-Dev.zip. Each contains exactly one variant DLL and two README files. Embedded DLL hashes match the appropriate compiled/staged DLLs. Source/verification remain in Releases/ApocaDustStorm-0.1.26-Developer.zip, with no compiled DLL/EXE files.

Source/build.ps1 defaults to release; -Development enables APOCA_DEV and defaults to Source/build-dev. Source/DEV-README.md documents dev controls. Saved-version.json and SHA256SUMS.txt record the preserved project and both variants. Previous releases are retained.

No game installation, live game configuration changes or Nexus upload were performed. ApocaGearbox and ApocaChaseCamera remain unchanged. Previous detailed research and correction notes are preserved in Verification/History/0.1.25-verification.md and the earlier developer archives.
